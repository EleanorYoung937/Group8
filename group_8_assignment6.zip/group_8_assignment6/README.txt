Open the group_8_assignment6.pde document and run it.
Move the mouse around to see how the ball and slingshot track with it.
Aim the ball and click to release it.
Close the program.
Repeat until satisfied.