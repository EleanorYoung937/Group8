Click run to start the game.
Press arrow keys to move your aircraft in different directions.
Press 'z' 'x' 'c' 'v' to change shooting mode.
Press 'b' for one time use of bomb to clear whole screen, but invadors cleared by this method will not be counted.
Press 'p' to pause the game, and then press 'r' to restart or press 'q' to quit.
Press 's' to change speed, there are choices of 1x, 2x and 3x the original speed.
Press 't' to screenshot
After shooting 10 invaders off, you win the game. Press 'r' to restart or press 'q' to quit.
Each time a invader landed on the bottom of screen, your lives become 1 less. 
After 3 invaders landing, you loss the game. Press 'r' to restart or press 'q' to quit.
