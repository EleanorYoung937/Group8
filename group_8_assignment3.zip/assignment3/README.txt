1. Run the python file extract_words.py
2. Go into each subdirectory and run the .pde files to produce our visualization of novel words and frequency.